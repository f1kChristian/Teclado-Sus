plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tecladop2pv2.core.diagnostics"
    compileSdk = 35
    defaultConfig { minSdk = 26 }
}
